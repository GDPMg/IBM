import { } from 'react'
import "./Footer.scss"


function Footer() {
  
  return (
    <>
       <footer>
        <p>Termos de Uso - Política de Privacidade</p>
        <p id="direitos_footer">@2023 -Todos os direitos reservados</p>
       </footer>
    </>
  )
}

export default Footer