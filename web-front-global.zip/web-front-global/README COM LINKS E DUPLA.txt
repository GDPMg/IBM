Link GitHub:https://github.com/GDPMg/Global-Solution-Front-Web

Guilherme Dal Posolo Matheus / RM: 98694 
Gustavo Brisqui Martinez / RM: 97969

Dados para logar: 
Usuario: usuario1 
Senha: senha123

Instrução: Ao abrir o projeto você será direcionado automaticamente para a aba "Login", no qual so conseguirá ir para o Home ao realizar o Login.